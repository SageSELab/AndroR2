package ch.logixisland.anuto.engine.theme;

public interface ThemeListener {
    void themeChanged();
}
