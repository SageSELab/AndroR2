package ch.logixisland.anuto.entity;

public interface EntityListener {
    void entityRemoved(Entity obj);
}
