package ch.logixisland.anuto.business.control;

public interface TowerInfoView {
    void showTowerInfo(TowerInfo towerInfo);
    void hideTowerInfo();
}
