package ch.logixisland.anuto.business.score;

public interface BonusListener {
    void bonusChanged(int waveBonus, int earlyBonus);
}
