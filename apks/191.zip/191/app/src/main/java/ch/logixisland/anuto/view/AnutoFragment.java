package ch.logixisland.anuto.view;

import android.app.Fragment;

public class AnutoFragment extends Fragment {

}
