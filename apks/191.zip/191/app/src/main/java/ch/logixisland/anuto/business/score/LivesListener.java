package ch.logixisland.anuto.business.score;

public interface LivesListener {
    void livesChanged(int lives);
}
