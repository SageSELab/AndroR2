package ch.logixisland.anuto.engine.render.sprite;

import android.graphics.Canvas;

public interface SpriteListener {
    void draw(SpriteInstance sprite, Canvas canvas);
}
