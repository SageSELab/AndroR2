package ch.logixisland.anuto.entity.tower;

public enum TowerStrategy {
    Closest,
    Weakest,
    Strongest,
    First,
    Last
}
