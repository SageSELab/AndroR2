package ch.logixisland.anuto.business.manager;

public interface GameListener {
    void gameStarted();

    void gameOver();
}
