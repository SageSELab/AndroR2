package ch.logixisland.anuto.util.data;

public enum WeaponType {
    None,
    Bullet,
    Laser,
    Explosive
}
