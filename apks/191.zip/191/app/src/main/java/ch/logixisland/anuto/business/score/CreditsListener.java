package ch.logixisland.anuto.business.score;

public interface CreditsListener {
    void creditsChanged(int credits);
}
