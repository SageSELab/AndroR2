package ch.logixisland.anuto.engine.theme;

public enum ActivityType {
    Game,
    Menu
}
