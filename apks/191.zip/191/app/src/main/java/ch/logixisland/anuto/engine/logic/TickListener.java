package ch.logixisland.anuto.engine.logic;

public interface TickListener {
    void tick();
}
